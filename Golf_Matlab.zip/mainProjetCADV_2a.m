%% initiation
close all
%bdclose all %Close any or all Simulink systems
clc

%Conversion des unit�s
KTS2MS = 1852 / 3600;
FL2M = 30.48;
RAD2DEG = 180/pi;
DEG2RAD = pi/180.;
FPM2MS = 0.3048/60;
gGravite = 9.80665; % m/s^2

%Indexation des composantes du vecteur d'etat
iy = 1; % m
ihp = 2; % m
iVa = 3; % m/s
ialpha = 4; % rad
itheta = 5; % rad
iq = 6; % rad/sec
TOTAL_SV = 6;

%Indexation des composantes du vecteur de commande
idPHR = 1;
ithr = 2;
idelevator = 3;
TOTAL_CMD = 3;

%Choix de l'�quipe
groupe = 'golf' %rentrer son groupe
[aircraftChosen, aircraftName, hTrimFL, Eas_KTS, ms, km] = utGetTrimPoint(groupe);

%% Commande Classique (de l'assiette)

VaTrim = utEas2Tas(Eas_KTS*KTS2MS, hTrimFL*FL2M);
hTrim = hTrimFL*FL2M;
dthrIdle = 0.1;
trimVal = utComputeTrimIdle(hTrim,VaTrim,aircraftChosen,km,ms,dthrIdle); %trim thrust idle
dPHRTrim = trimVal(1); %rad
alphaTrim = trimVal(2); %rad
thetaTrim = trimVal(3); %rad
fpaDeg = RAD2DEG*(thetaTrim-alphaTrim); %pente, flight path angle

%Linearisation
%vecteur d'etat au point de trim
xTrim = zeros(TOTAL_SV, 1);
xTrim(ihp) = hTrim; %m
xTrim(iVa) = VaTrim; %m/sec
xTrim(ialpha) = alphaTrim; %rad
xTrim(itheta) = thetaTrim; %rad
% Vecteur de commande au point de trim choisi
uTrim = zeros(TOTAL_CMD, 1);
uTrim(idPHR) = dPHRTrim;
uTrim(ithr) = dthrIdle;
uTrim(idelevator) = 0;

% V�rification trim
xdotTrim = utAcDynamicsFunction(xTrim,uTrim,aircraftChosen,km,ms);

% Lin�arisation autour du point de trim
[A, B, C, D] = linmod('acDynModel_ToLinearize_2015',xTrim, uTrim);


A4 = A(iVa:iq, iVa:iq); % on tronque afin de simplifier le syst�me (on ne veut pas l'altitude ou position)
B4 = B(iVa:iq, idelevator);

C4 = [0, 0, 1, 0];
D4 = 0;

[state4num, state4den] = ss2tf(A4, B4, C4, D4);
state4 = tf(state4num, state4den); % on obtient une fonction de transfert SISO pour controler l'assiette

% V�rification de la controlabilit� et observabilit� du syst�me
ctrPID = rank(ctrb(A4,B4));
obsPID = rank(obsv(A4,C4));
nPID = size(A4,1);

if ctrPID < nPID, disp('PID non contr�lable'); end
if obsPID < nPID, disp('PID non observable'); end


% Calcul des modes de A4
modes4 = eig(A4);
[Wn, zeta] = damp(A4);

% Specifications�
ts = 3; % secondes
D = 0.05; % d�passement de 5% tol�r�
[Kp, Ki, Kd, m, w0, dp] = utWang(state4, ts, D, -5.66); % On prend Kp = - 5.66, par lecture du root locus

% Pr�filtre
FTBF_in = feedback(state4, tf([Kp, 0], 1)); % Fonction de transfert 'interne' pour assiette
FTBF = feedback(tf([Kp, Ki], [1, 0])*FTBF_in, 1);
pole(FTBF);
zero(FTBF);

minFTBF = minreal(FTBF, 1e-4); %nous avons un pole � presque zero qu'il faut enlever

q = minFTBF.den{1}; % D�nominateur de la FTBF
Cpf = tf(q(end), minFTBF.num{1}); % pr�filtre d'ordre 2
Cpf1 = tf(1,[dp,1]); % pr�filtre d'ordre 1


%% Commande Modale (de la vitesse pilot�e via l'assiette)

% Linearisation

% Vecteur d'etat au point de trim pour commande modale
xTrimcm = zeros(8, 1);
xTrimcm(ihp) = hTrim; %m
xTrimcm(iVa) = VaTrim; %m/sec
xTrimcm(ialpha) = alphaTrim; %rad
xTrimcm(itheta) = thetaTrim; %rad

% Vecteur de commande au point de trim choisi
uTrimcm = 0;

% Linearisation autour du point de trim
[Acm, Bcm, Ccm, Dcm] = linmod('Golf_Nonlin_Classique',xTrimcm, uTrimcm);

% Commandablite et Observabilit� du systeme
ctrClassique = rank(ctrb(Acm,Bcm));
obsClassique = rank(obsv(Acm,Ccm));
nClassique = size(Acm,1);
if ctrClassique < nClassique, disp('Syst�me non contr�lable'); end
if obsClassique < nClassique, disp('Syst�me non observable'); end


A6 = Acm(iVa:end, iVa:end); % on tronque pour simplifier le syst�me
B6 = Bcm(iVa:end); 
C6 = Ccm(iVa:end, iVa:end);
C6_pour_h = Ccm(iVa, iVa:end); % on veut stabiliser la vitesse
pA6 = eig(A6); % on trouve des poles � presque zero qu'il faut changer
K6 = place(A6,B6,[dp, conj(dp), -3.3965 + 0.1541i, -3.3965 - 0.1541i, -5, -6]); % On a observ� les p�les (-3.3965 + 0.1541i, -3.3965 - 0.1541i) dans eig
% On se contente de les conserver ici, pour soulager les actionneurs. On a
% les poles d�sir�s et aussi des poles rapides.
% Inutile de lutter contre les poles de eig

% On doit identifier quelle ligne de C6 correspond � Va pour l'int�grateur
C_Va = zeros(1, size(A6, 2));
C_Va(1) = 1; % On extrait Va

% Cr�ation du syst�me augment� (Ajout de l'�tat int�grateur)
A_aug = [A6, zeros(size(A6,1), 1); -C_Va, 0];

B_aug = [B6; 0];

% Calcul des gains sur le syst�me augment� (taille 7)
% On ajoute un p�le pour l'int�grateur
poles_desires = [dp, conj(dp), -3.3965 + 0.1541i, -3.3965 - 0.1541i, -3, -4, -10.33];

K_aug = place(A_aug, B_aug, poles_desires);

% S�paration des gains pour Simulink
K_x = K_aug(1:end-1); % Gains pour le retour d'�tat classique
K_i = K_aug(end);% Gain pour l'int�grateur


% Precommande
H = -inv(C6_pour_h*inv(A6-B6*K_x)*B6);

% Estimateur
Cobs = [C6(1,:); C6(3,:); C6(4,:)]; %on veut se servir de la vitesse, de l'assiette, et le tangage

%V�rification de l'observabilit� et controlabilit� de l'estimateur
obsLuenberger = rank(obsv(A6,Cobs));
ctrLuenberger = rank(ctrb(A6, B6));
nLuenberger = size(A6,1);
if ctrLuenberger < nLuenberger, disp('Estimateur Luenberger non contr�lable'); end
if obsLuenberger < nLuenberger, disp('Estimateur Luenberger non observable'); end


L6t = place(A6', Cobs', poles_desires(1:6));
L6 = L6t';
eig(A6-L6*Cobs); % on controle que les valeurs propres sont n�gatives donc syst�me stable

A_obs = A6 - L6*Cobs;
sys_obs = ss(A_obs, eye(6), eye(6), zeros(6));

% Affichage des p�les sur le plan complexe
% figure;
% pzmap(sys_obs);
% grid on;
% title('P�les de l''observateur (Valeurs propres de A - LC)');

%% Commande Optimale/MIMO

taero = 20; % Temps de r�ponse capture vitesse a�rodynamique
Daero = 0; % D�passement � la r�ponse indicielle

tpente = 2; % Temps de r�ponse capture pente
Dpente = 0; % D�passement � la r�ponse indicielle

%lin�arisation en palier pour les nouvelles conditions de vol
hTrimLF = 30*FL2M; % m
VaTrimLF = utEas2Tas(230*KTS2MS, hTrimLF); % m/s, 230 depuis la consigne
trimValLF = utComputeTrimLevelFlight(hTrimLF,VaTrimLF,aircraftChosen,km,ms); %trim thrust idle (dphr, alpha, dthr)

dPHRTrimLF = trimValLF(1); %rad
alphaTrimLF = trimValLF(2); %rad
thetaTrimLF = trimValLF(2); %rad
dthrTrimLF = trimValLF(3);
fpaDegLF = RAD2DEG*(thetaTrimLF-alphaTrimLF); %pente, flight path angle

xTrimLF = zeros(TOTAL_SV, 1);
xTrimLF(ihp) = hTrimLF; %m
xTrimLF(iVa) = VaTrimLF; %m/s
xTrimLF(ialpha) = alphaTrimLF; %rad
xTrimLF(itheta) = thetaTrimLF; %rad

% Vecteur de commande au point de trim choisi
uTrimLF = zeros(TOTAL_CMD, 1);
uTrimLF(idPHR) = dPHRTrimLF;
uTrimLF(ithr) = trimValLF(3);
uTrimLF(idelevator) = 0;

% V�rification trim
xdotTrimLF = utAcDynamicsFunction(xTrimLF,uTrimLF,aircraftChosen,km,ms);
[Alf, Blf, Clf, Dlf] = linmod('acDynModel_ToLinearize_2015',xTrimLF , uTrimLF);

% V�rification de controlabilit� et observabilit� du syst�me lin�aris� pour LF
ctrMIMO = rank(ctrb(Alf,Blf));
obsMIMO = rank(obsv(Alf,Clf));
nMIMO = size(Alf);
if ctrMIMO < nMIMO, disp('Syst�me MIMO non contr�lable'); end
if obsMIMO < nMIMO, disp('Syst�me MIMO non observable'); end

% Extraction pour LQT/tronquage pour ne pas utiliser h et y
idx_states = iVa:iq; 
idx_inputs = ithr:idelevator; % Entr�es : Pouss�e et Gouverne

A_sys = Alf(idx_states, idx_states);
B_sys = Blf(idx_states, idx_inputs);


C_sys = [1,  0, 0, 0; 
         0, -1, 1, 0]; % on fait sortir la pente = assiette - incidence
     
D_sys = zeros(4,2);

% V�rification des p�les du syst�me (pratiquement les m�mes qu'avant)
poles_sys = eig(A_sys);

% Mod�le de R�f�rence

Ar = [-3/taero, 0; 
       0,      -3/tpente];

Br = [3/taero, 0; 
      0,       3/tpente];
  
Cr = eye(2);

Dr = zeros(2,2);


Aaug = [A_sys, zeros(4,2);
        zeros(2,4), Ar];
    
Baug = [B_sys; zeros(2,2)];

Caug = [C_sys, -Cr];

Daug = zeros(2,2);

N = [Aaug, Baug;
    Caug, zeros(2,2)];

% Dimensions
n_states = size(A_sys, 1); % 4
n_ref = size(Ar, 1);       % 2 
n_inputs = size(B_sys, 2); % 2
n_outputs = size(C_sys, 1);% 2

% Suite Commande Optimale/MIMO : Calcul des gains LQT

% D�finition des poids pour le crit�re quadratique J
% Q pour l'erreur de suivi
q_Va = 1000; %1 / (40)^2;      % Erreur en vitesse % 40 pour le lin�aire marche bien
q_gamma = 1000; %1 / (0.01)^2; % On veut tol�rer 0.01 rad (environ 0.5 deg) d'erreur
Q = diag([q_Va, q_gamma]);

% R pour p�naliser les commandes
r_th = 1;% / (0.5)^2;     % Pour la pouss�e % 0.5 en lin�aire marche bien
r_el = 1;% / (0.26)^2;     % Pour la gouverne (environ 15 deg) % 0.26 en lin�aire marche bien
R = diag([r_th, r_el]);

% Equation de Riccati (LQR augment�)

Q_aug = Caug' * Q * Caug;

% Calcul du gain optimal K_aug = [Kx, Kr]
[Kaug, S, E] = lqr(Aaug, Baug, Q_aug, R); % on obtient les gains 

% Extraction des gains
Kx = Kaug(:, 1:4); % Gain de retour d'�tat (sur Va, alpha, theta, q)
Kr = Kaug(:, 5:6); % Gain sur l'�tat du mod�le de r�f�rence (en sortie)

%V�rification de l'observabilit� et commandabilit� du pr�filtre optimal
ctrOPT = rank(ctrb(A_sys, B_sys));
obsOPT = rank(obsv(A_sys, C_sys));
nOPT = size(A_sys,1);
if ctrOPT < nOPT, disp('Pr�filtre optimal non contr�lable'); end
if obsOPT < nOPT, disp('Pr�filtre optimal non observable'); end

RHS_Mat = [zeros(n_states, n_ref); 
           -Br; 
           zeros(n_outputs, n_ref)];

% R�solution pour trouver les matrices de gains statiques
M = N \ RHS_Mat;

Nx = M(1:n_states, :);               
Nxr = M(n_states+1:n_states+n_ref, :);
Nu = M(end-n_inputs+1:end, :);     

% Calcul de la sortie pr�filtre Dpf 

Dpf = Kaug * [Nx; Nxr] + Nu;









