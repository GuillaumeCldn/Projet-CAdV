function Iyy = utComputeIyy(mass,Lfus)
    Iyy = 0.5*(1/12*mass*Lfus^2);
end
